import React, { useState } from 'react'
import { Link,useNavigate } from 'react-router-dom';
import EmpNavbar from './EmpNavbar';


function Registration() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [contact, setContact] = useState("");
    const [dob, setDOB] = useState("");
    const [gender, setGender] = useState("");
    const [Acctype, setAcctype] = useState("");
    const [aadhar, setAadhar] = useState("");
    const [deposite, setDeposite] = useState("");
    const [password, setPassword] = useState("");
    const [address, setAddress] = useState("");
    const [err,setErr]=useState("");


    function handleDeposite(e){
        setDeposite(parseInt(e.target.value))
        let depo=e.target.value
        if(depo<10000){
            setErr("Minimum account opening balance is 10000")
        }
        else{
            setErr(""); 
        }
    }

    // const navigate = useNavigate();

    function handleRegister(e) {
        e.preventDefault();
        console.log("Name : " + name);
        console.log("Email : " + email);
        console.log("Contact : " + contact);
        console.log("DOB : " + dob);
        console.log("Gender: " + gender);
        console.log("Acctype : " + Acctype);
        console.log("aadhar : " + aadhar);
        console.log("balance : " + deposite);
        console.log("password : " + password);
        console.log("address : " + address);

        const setData = async () => {
            try {
                const result = await fetch("http://localhost:4800/", {
                    method: "post",
                    headers: {
                        'Content-type': 'application/json; charset=UTF-8',
                    },
                    body: JSON.stringify({
                        Acc_No: '0',
                        Name: name,
                        Email: email,
                        Contact: contact,
                        DOB: dob,
                        Gender: gender,
                        Acc_Type: Acctype,
                        Aadhar: aadhar,
                        Balance: deposite,
                        Password: password,
                        Address: address
                    })
                })
                const response = await result.json();

                console.log(response);

                alert("Account opened successfully..");
            }
            catch (error) {
                console.log(error);
            }
        }
        setData();
    }

    if (sessionStorage.getItem("emp") != null) {
        return (
            <div>
                <EmpNavbar />
                <div className="container bg-new p-5 mt-5">
                    <form onSubmit={handleRegister}>
                        <h1 className="text-center mb-5">New Account Opening Form..</h1>
                        <div className="form-group mb-3">
                            <label for="name">Name</label>
                            <input type="text" id="name" className="form-control" placeholder="*Enter Full Name" onChange={(e) => setName(e.target.value)} />
                        </div>

                        <div className="form-group mb-3">
                            <label for="email">Email</label>
                            <input type="text" id="email" className="form-control" placeholder="*Enter email" onChange={(e) => setEmail(e.target.value)} />
                        </div>

                        <div className="form-group mb-3">
                            <label for="contact">Contact Number</label>
                            <input type="text" id="contact" className="form-control" placeholder="*Enter Contact Number" onChange={(e) => setContact(e.target.value)} />
                        </div>

                        <div className="form-group mb-3">
                            <label for="dob">Date Of Birth</label>
                            <input type="date" id="dob" className="form-control" onChange={(e) => setDOB(e.target.value)} />
                        </div>

                        <div className="form-group mb-3" onChange={(e) => setGender(e.target.value)}>
                            <label for="gender" className="d-block mb-2">Gender</label>
                            <input type="radio" id="dob" name="gender" className="me-2" value="Male" /><span className="me-3">Male</span>
                            <input type="radio" id="dob" name="gender" className="me-2" value="Female" /><span className="me-3">Female</span>
                            <input type="radio" id="dob" name="gender" className="me-2" value="Other" /><span className="me-3">Other</span>
                        </div>

                        <div className="form-group mb-3">
                            <label for="acctype">Account Type</label>
                            <select className="form-control" id="acctype" onChange={(e) => setAcctype(e.target.value)}>
                                <option>Select Account Type</option>
                                <option>Saving</option>
                                <option>Current</option>
                            </select>
                        </div>

                        <div className="form-group mb-3">
                            <label for="aadhar">Aadhar Number</label>
                            <input type="password" id="addhar" className="form-control" placeholder="*Enter addhar number" onChange={(e) => setAadhar(e.target.value)} />
                        </div>

                        <div className="form-group mb-3">
                            <label for="deposite">Initial Deposite Amount</label>
                            <input type="number" id="deposite" className="form-control" placeholder="*Enter addhar number" onChange={(e)=>handleDeposite(e)} />
                            <div className='text-danger'>{err}</div>
                        </div>

                        <div className="form-group mb-3">
                            <label for="password">Password</label>
                            <input type="password" id="password" className="form-control" placeholder="*Enter Password" onChange={(e) => setPassword(e.target.value)} />
                        </div>

                        <div className="form-group mb-3">
                            <label for="address">Address</label>
                            <textarea className="form-control" id="address" rows="3" onChange={(e) => setAddress(e.target.value)}></textarea>
                        </div>

                        <div className="form-group">
                            <input type="reset" className="btn btn-primary me-3" value="Reset" />
                            <input type="submit" className="btn btn-primary" value="Register" />
                        </div>
                    </form>
                </div>
            </div>
        )
    }
    else{
        return <div className='text-center text-danger m-5'>You are invalid user. Please login first. <Link to="/login">Go to login</Link></div>
    }
}

export default Registration