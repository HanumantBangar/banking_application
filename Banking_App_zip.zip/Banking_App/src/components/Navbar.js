import React from 'react';
import {Link} from 'react-router-dom'

function Navbar() {
    return (
        <div>
            <nav className="navbar navbar-expand-lg bg-body-tertiary">
                <div className="container-fluid bg-dark">
                    <Link className="navbar-brand fs-1 text-info col-4" to="">HSB Bank</Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse col-8 justify-content-end p-3" id="navbarNavDropdown">
                        <ul className="navbar-nav">
                            <li className="nav-item me-3">
                                <Link className="nav-link active" aria-current="page" to="#">Home</Link>
                            </li>
                            <li className="nav-item me-3">
                                <Link className="nav-link" to="#">Services</Link>
                            </li>
                            <li className="nav-item me-3">
                                <Link className="nav-link" to="#">About Us</Link>
                            </li>
                            <li className="nav-item dropdown me-3">
                                <Link className="nav-link dropdown-toggle" to="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Login
                                </Link>
                                <ul className="dropdown-menu">
                                    <li><Link className="dropdown-item" to="#">Employee</Link></li>
                                    <li><Link className="dropdown-item" to="/login">Customer</Link></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    )
}

export default Navbar