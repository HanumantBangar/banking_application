import React from 'react';
import { Link } from 'react-router-dom';

function EmpNavbar() {
    const handleLogin = () => {
        sessionStorage.clear();
    }
    return (
        <div>
            <nav className="navbar navbar-expand-lg bg-dark text-light" >
                <div className="container-fluid fs-5 ms-3">
                    <a className="navbar-brand text-light fs-2" href="#">HSB Bank</a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon bg-light text-light"></span>
                    </button>
                    <div className="collapse navbar-collapse col-6 justify-content-end" id="navbarNavAltMarkup">
                        <div className="navbar-nav">
                            <Link className="nav-link text-light me-3" aria-current="page" to="">Home</Link>
                            {/* <Link className="nav-link text-light me-3" to="/services">Services</Link> */}
                            <Link className="nav-link text-light me-3" to="/newAccount">Open New Account</Link>
                            <Link className="nav-link text-light me-3" to="/customerDetails">View All Customer Details</Link>
                            <Link className="nav-link text-light me-3 btn btn-success" to="/login" onClick={handleLogin}>Logout</Link>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    )
}

export default EmpNavbar