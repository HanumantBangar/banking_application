import React, { useState } from 'react'

function CheckBalance() {
    const [acc,setAcc]=useState("");
    const [data,setData]=useState("");
    function showBalance(){
        const getData=async()=>{
            try{
                const result=await fetch("http://localhost:4800/search/"+acc)
                const resp=await result.json();
                console.log(resp);
                setData(resp[0])
            }
            catch(error){
                console.log(error)
            }
        }
        getData();
    }
  return (
    <div className='container w-50 text-center bg-secondary px-5'>
        <div className='row'>
            <div className='col'>
                <h1 className='text-info mb-3'>Account Balance Details</h1>
                <div className='bg-info mb-3'>
                    <h3 className='text-center text-light'><i class="fa-solid fa-indian-rupee-sign me-2"></i>{data.Balance}</h3>
                </div>
                <input type='number' placeholder='Enter Account Number' onChange={(e)=>setAcc(e.target.value)} className='w-100 mb-3'></input>
                <button className='btn btn-primary w-100 mb-3' onClick={showBalance}>Check Balance</button>
                
            </div>
        </div>
    </div>
  )
}

export default CheckBalance;