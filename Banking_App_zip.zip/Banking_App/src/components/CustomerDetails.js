import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import EmpNavbar from './EmpNavbar';

function CustomerDetails() {
    const [data, setData] = useState([]);
    const getData = async () => {
        try {
            const result = await fetch("http://localhost:4800/")
            const resp = await result.json();
            console.log(resp);
            setData(resp);
        }
        catch (error) {
            console.log(error)
        }
    }
    useEffect(() => {
        getData();
    }, [])

    if (sessionStorage.getItem("emp") != null) {
        return (
            <div>
                <EmpNavbar />
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>Account Number</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Contact Number</th>
                            <th>Date Of Birth</th>
                            <th>Gender</th>
                            <th>Account Type</th>
                            <th>Account Balance</th>
                            <th>Aadhar Number</th>
                            <th>Address</th>

                        </tr>
                    </thead>
                    <tbody>
                        {
                            data.map(ele => {
                                return <tr>
                                    <td>{ele.Acc_NO}</td>
                                    <td>{ele.Name}</td>
                                    <td>{ele.Email}</td>
                                    <td>{ele.Contact}</td>
                                    <td>{ele.DOB}</td>
                                    <td>{ele.Gender}</td>
                                    <td>{ele.Acc_Type}</td>
                                    <td>{ele.Balance}</td>
                                    <td>{ele.Aadhar}</td>
                                    <td>{ele.Address}</td>
                                </tr>
                            })
                        }
                    </tbody>
                </table>
            </div>
        )
    }
    else{
        return <div className='text-center text-danger m-5'>You are invalid user. Please login first. <Link to="/login">Go to login</Link></div>
    }
}


export default CustomerDetails