import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import Navbar from './Navbar';

function Login() {
    const [acc, setAcc] = useState("");
    const [pass, setPass] = useState("");
    const [err, setErr] = useState("");
    const navigate = useNavigate();

    function handleLogin(e) {
        e.preventDefault();
        const getData = async () => {
            try {
                const result = await fetch(`http://localhost:4800/login/${acc}/${pass}`);
                const resp = await result.json();
                const data = JSON.stringify(resp[0])

                if((acc==='0000')&&(pass==='employee@123')){
                    sessionStorage.setItem("emp","only employee")
                    navigate("/empLogin")
                }
                else if (resp.length) {
                    sessionStorage.setItem("Acc_No", acc);
                    navigate("/customerProfile");
                }
                else {
                    setErr("Invalid Account Number and Password !")
                }

            }
            catch (error) {
                console.log(error);
            }
        }
        getData();
    }

    return (
        <div>
            <Navbar />
            <div className="container w-60 bg-new p-5 mt-5 b-radius-50">
                <div className='text-danger text-center mb-2'>{err}</div>
                <h1 className="text-center text-info mb-5">Login Here..</h1>
                <form onSubmit={handleLogin}>
                    <div class="mb-3">
                        <label for="account" className="form-label">Account Number</label>
                        <input type="number" className="form-control" id="account" aria-describedby="emailHelp" onChange={(e) => setAcc(e.target.value)} />
                        <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
                    </div>
                    <div class="mb-3">
                        <label for="password" className="form-label">Password</label>
                        <input type="password" className="form-control" id="password" onChange={(e) => setPass(e.target.value)} />
                    </div>
                    <button type="submit" className="btn btn-primary px-3">Login</button>
                </form>
            </div>
        </div>
    )
}

export default Login