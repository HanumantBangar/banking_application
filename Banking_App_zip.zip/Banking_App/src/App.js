import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import CheckBalance from './components/CheckBalance';
import CustomerDetails from './components/CustomerDetails';
import CustomerProfile from './components/CustomerProfile';
import EmpNavbar from './components/EmpNavbar';
import Login from './components/Login';
import Navbar from './components/Navbar';
import Registration from './components/Registration';

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Navbar/>}/>
          <Route path='/login' element={<Login/>}/>
          <Route path='/empLogin' element={<EmpNavbar/>}/>
          <Route path='/newAccount' element={<Registration/>}/>
          <Route path='/customerDetails' element={<CustomerDetails/>}/>
          <Route path='/customerProfile' element={<CustomerProfile/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;


