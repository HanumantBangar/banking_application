const express=require('express');
const mysql=require('mysql')
const app=express();
const cors=require('cors');
app.use(cors());
app.use(express.json());

const con=mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "banking_app"
});

con.connect((error)=>{
    if(error)
        console.log("Database Not Connected..");
    else
        console.log("Database Connected..")
});



app.get("/",(req,resp)=>{
    con.query('select * from customer',(error,result)=>{
        if(error)
            console.log("Error is "+error);
        else
            resp.send(result);
    });
});



app.get("/search/:Acc_NO",(req,res)=>{
    let Acc=req.params.Acc_NO;
    con.query("select * from customer where Acc_NO=?",[Acc],function(err,result){
      if(err){
        res.send("error")
      }else{
        res.send(result)
      }
    })
  })

app.get("/login/:Acc_No/:Password",(req,res)=>{
    let Acc_No=req.params.Acc_No;
    let password=req.params.Password;
    con.query("select * from customer where Acc_NO=? and Password=?",[Acc_No,password],function(err,result){
      if(err){
        res.send("error")
      }else{
        res.send(result)
        return result;
      }
    })
  })

app.post("/",(req,resp)=>{
    const data=req.body;
    con.query('insert into customer set ?',data,(error,result,fields)=>{
        if(error)
            console.log("error is "+error);
        else
        {
            resp.send(result);
        }
    });
});

app.patch("/:Acc_NO",(req,resp)=>{
  const data=[req.body.Balance,req.params.Acc_NO]
  con.query('update customer set Balance=? where Acc_NO=?',data,(error,result,fields)=>{
      if(error)
          console.log("error is "+error);
      else
      {
          resp.send("successfully..");
          return result;
      }
  });
});

app.delete("/delete/:id",(req,resp)=>{
  const id=req.params.id;
  con.query('delete from userdetails where Uid=?',[id],(error,result,fields)=>{
    if(error)
          console.log("error is "+error);
      else
      {
          resp.send("successfully..");
          return result;
      }
  })
});

app.listen(4800);
